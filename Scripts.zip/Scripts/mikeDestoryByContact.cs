﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class mikeDestoryByContact : MonoBehaviour
{
    public static float p1Score = 0;
    public static float p2Score = 0;
    public float countdown = 3;
    private Scene mainScene;
    public GameObject explosion;
    
    private GameObject player1;
    private GameObject player2;

    public Text blueScore;
    public Text redScore;


    private void Start()
    {
        player1 = GameObject.FindWithTag("player1");
        player2 = GameObject.FindWithTag("player2");
        

        mainScene = SceneManager.GetActiveScene();
    }

    private void Update()
    {

        //track scores
        blueScore.text = "Blue:" + p2Score;
        redScore.text = "Red:" + p1Score;

        if (p2Score >= 5)
        {
            Debug.Log("Player2");
            //load Win Screen for Player 2
            SceneManager.LoadScene(3);
        }
        if (p1Score>= 5)
        {
            Debug.Log("Player1");
            //load Win Screen for Player 1
            
            SceneManager.LoadScene(2);
        }
    }

    private void OnTriggerEnter2D(Collider2D other) 
    {
        if (other.CompareTag("player1")){
            //Instantiate(explosion, other.transform.position, other.transform.rotation);
            Destroy(player1);
            Destroy(gameObject);
            p2Score++;
            Debug.Log(p2Score);

            //countdown -= Time.deltaTime; has to go in update          
            SceneManager.LoadScene(mainScene.name);
        }
        if (other.CompareTag("player2"))
        {
            //Instantiate(explosion, other.transform.position, other.transform.rotation);
            Destroy(player2);
            Destroy(gameObject);
            p1Score++;
            Debug.Log(p1Score);
            //countdown -= Time.deltaTime; // has to go in update
            SceneManager.LoadScene(mainScene.name);
        }
        

    }
     
}
