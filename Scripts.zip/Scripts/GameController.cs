﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public float startDelay;
    public float enemyDelay;
    public float waveDelay;    
    public int enemiesInWave;
    public GameObject[] enemyPrefabs;    
    public Transform[] lanes;
   
    void Start()
    {                
        StartCoroutine(SpawnWaves());
    }
    

    IEnumerator SpawnWaves()
    {
        yield return new WaitForSeconds(startDelay);
        while (true) //spawn a wave
        {
            for (int i = 0; i < enemiesInWave; i++) //Added threat level to this so it spawns more units per wave
            {
                Vector2 spawnPosition = lanes[Random.Range(0, lanes.Length)].position; //Place at which they spawn x is a range, y is set.
                Instantiate(enemyPrefabs[Random.Range(0, enemyPrefabs.Length)], spawnPosition, Quaternion.identity); //Randomize Enemy
                //Randomize position
                yield return new WaitForSeconds(enemyDelay);
            }            
            yield return new WaitForSeconds(waveDelay);
        }
    }
      

}
