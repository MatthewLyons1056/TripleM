﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class player2Control : MonoBehaviour
{
    public float speed;
    Rigidbody2D rb;
    public BoxCollider2D playArea;


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveH = Input.GetAxisRaw("P2Horizontal");
        float moveV = Input.GetAxisRaw("P2Vertical");

        Vector2 move = new Vector2(moveH, moveV);
        rb.velocity = move * speed;

        float clampX = Mathf.Clamp(rb.position.x, playArea.bounds.min.x, playArea.bounds.max.x);
        float clampY = Mathf.Clamp(rb.position.y, playArea.bounds.min.y, playArea.bounds.max.y);
        rb.position = new Vector2(clampX, clampY);
    }
}
